package b4a.example.walkietalkie.designerscripts;
import anywheresoftware.b4a.objects.TextViewWrapper;
import anywheresoftware.b4a.objects.ImageViewWrapper;
import anywheresoftware.b4a.BA;


public class LS_1{

public static void LS_general(java.util.LinkedHashMap<String, anywheresoftware.b4a.keywords.LayoutBuilder.ViewWrapperAndAnchor> views, int width, int height, float scale) {
anywheresoftware.b4a.keywords.LayoutBuilder.setScaleRate(0.3);
//BA.debugLineNum = 2;BA.debugLine="AutoScaleAll 'uncomment to scale all views based on the device physical size."[1/General script]
anywheresoftware.b4a.keywords.LayoutBuilder.scaleAll(views);
//BA.debugLineNum = 3;BA.debugLine="lblWifiStatus.SetLeftAndRight(lblWifiStatus.Left, 100%x)"[1/General script]
views.get("lblwifistatus").vw.setLeft((int)((views.get("lblwifistatus").vw.getLeft())));
views.get("lblwifistatus").vw.setWidth((int)((100d / 100 * width) - ((views.get("lblwifistatus").vw.getLeft()))));
//BA.debugLineNum = 4;BA.debugLine="lblBTStatus.SetLeftAndRight(lblBTStatus.Left, 100%x)"[1/General script]
views.get("lblbtstatus").vw.setLeft((int)((views.get("lblbtstatus").vw.getLeft())));
views.get("lblbtstatus").vw.setWidth((int)((100d / 100 * width) - ((views.get("lblbtstatus").vw.getLeft()))));
//BA.debugLineNum = 6;BA.debugLine="lblPTT.SetLeftAndRight(0, 100%x)"[1/General script]
views.get("lblptt").vw.setLeft((int)(0d));
views.get("lblptt").vw.setWidth((int)((100d / 100 * width) - (0d)));

}
}