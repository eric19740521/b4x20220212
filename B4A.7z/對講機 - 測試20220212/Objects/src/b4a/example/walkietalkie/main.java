package b4a.example.walkietalkie;


import anywheresoftware.b4a.B4AMenuItem;
import android.app.Activity;
import android.os.Bundle;
import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.B4AActivity;
import anywheresoftware.b4a.ObjectWrapper;
import anywheresoftware.b4a.objects.ActivityWrapper;
import java.lang.reflect.InvocationTargetException;
import anywheresoftware.b4a.B4AUncaughtException;
import anywheresoftware.b4a.debug.*;
import java.lang.ref.WeakReference;

public class main extends Activity implements B4AActivity{
	public static main mostCurrent;
	static boolean afterFirstLayout;
	static boolean isFirst = true;
    private static boolean processGlobalsRun = false;
	BALayout layout;
	public static BA processBA;
	BA activityBA;
    ActivityWrapper _activity;
    java.util.ArrayList<B4AMenuItem> menuItems;
	public static final boolean fullScreen = false;
	public static final boolean includeTitle = true;
    public static WeakReference<Activity> previousOne;
    public static boolean dontPause;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
        mostCurrent = this;
		if (processBA == null) {
			processBA = new BA(this.getApplicationContext(), null, null, "b4a.example.walkietalkie", "b4a.example.walkietalkie.main");
			processBA.loadHtSubs(this.getClass());
	        float deviceScale = getApplicationContext().getResources().getDisplayMetrics().density;
	        BALayout.setDeviceScale(deviceScale);
            
		}
		else if (previousOne != null) {
			Activity p = previousOne.get();
			if (p != null && p != this) {
                BA.LogInfo("Killing previous instance (main).");
				p.finish();
			}
		}
        processBA.setActivityPaused(true);
        processBA.runHook("oncreate", this, null);
		if (!includeTitle) {
        	this.getWindow().requestFeature(android.view.Window.FEATURE_NO_TITLE);
        }
        if (fullScreen) {
        	getWindow().setFlags(android.view.WindowManager.LayoutParams.FLAG_FULLSCREEN,   
        			android.view.WindowManager.LayoutParams.FLAG_FULLSCREEN);
        }
		
        processBA.sharedProcessBA.activityBA = null;
		layout = new BALayout(this);
		setContentView(layout);
		afterFirstLayout = false;
        WaitForLayout wl = new WaitForLayout();
        if (anywheresoftware.b4a.objects.ServiceHelper.StarterHelper.startFromActivity(this, processBA, wl, true))
		    BA.handler.postDelayed(wl, 5);

	}
	static class WaitForLayout implements Runnable {
		public void run() {
			if (afterFirstLayout)
				return;
			if (mostCurrent == null)
				return;
            
			if (mostCurrent.layout.getWidth() == 0) {
				BA.handler.postDelayed(this, 5);
				return;
			}
			mostCurrent.layout.getLayoutParams().height = mostCurrent.layout.getHeight();
			mostCurrent.layout.getLayoutParams().width = mostCurrent.layout.getWidth();
			afterFirstLayout = true;
			mostCurrent.afterFirstLayout();
		}
	}
	private void afterFirstLayout() {
        if (this != mostCurrent)
			return;
		activityBA = new BA(this, layout, processBA, "b4a.example.walkietalkie", "b4a.example.walkietalkie.main");
        
        processBA.sharedProcessBA.activityBA = new java.lang.ref.WeakReference<BA>(activityBA);
        anywheresoftware.b4a.objects.ViewWrapper.lastId = 0;
        _activity = new ActivityWrapper(activityBA, "activity");
        anywheresoftware.b4a.Msgbox.isDismissing = false;
        if (BA.isShellModeRuntimeCheck(processBA)) {
			if (isFirst)
				processBA.raiseEvent2(null, true, "SHELL", false);
			processBA.raiseEvent2(null, true, "CREATE", true, "b4a.example.walkietalkie.main", processBA, activityBA, _activity, anywheresoftware.b4a.keywords.Common.Density, mostCurrent);
			_activity.reinitializeForShell(activityBA, "activity");
		}
        initializeProcessGlobals();		
        initializeGlobals();
        
        BA.LogInfo("** Activity (main) Create, isFirst = " + isFirst + " **");
        processBA.raiseEvent2(null, true, "activity_create", false, isFirst);
		isFirst = false;
		if (this != mostCurrent)
			return;
        processBA.setActivityPaused(false);
        BA.LogInfo("** Activity (main) Resume **");
        processBA.raiseEvent(null, "activity_resume");
        if (android.os.Build.VERSION.SDK_INT >= 11) {
			try {
				android.app.Activity.class.getMethod("invalidateOptionsMenu").invoke(this,(Object[]) null);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

	}
	public void addMenuItem(B4AMenuItem item) {
		if (menuItems == null)
			menuItems = new java.util.ArrayList<B4AMenuItem>();
		menuItems.add(item);
	}
	@Override
	public boolean onCreateOptionsMenu(android.view.Menu menu) {
		super.onCreateOptionsMenu(menu);
        try {
            if (processBA.subExists("activity_actionbarhomeclick")) {
                Class.forName("android.app.ActionBar").getMethod("setHomeButtonEnabled", boolean.class).invoke(
                    getClass().getMethod("getActionBar").invoke(this), true);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (processBA.runHook("oncreateoptionsmenu", this, new Object[] {menu}))
            return true;
		if (menuItems == null)
			return false;
		for (B4AMenuItem bmi : menuItems) {
			android.view.MenuItem mi = menu.add(bmi.title);
			if (bmi.drawable != null)
				mi.setIcon(bmi.drawable);
            if (android.os.Build.VERSION.SDK_INT >= 11) {
				try {
                    if (bmi.addToBar) {
				        android.view.MenuItem.class.getMethod("setShowAsAction", int.class).invoke(mi, 1);
                    }
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			mi.setOnMenuItemClickListener(new B4AMenuItemsClickListener(bmi.eventName.toLowerCase(BA.cul)));
		}
        
		return true;
	}   
 @Override
 public boolean onOptionsItemSelected(android.view.MenuItem item) {
    if (item.getItemId() == 16908332) {
        processBA.raiseEvent(null, "activity_actionbarhomeclick");
        return true;
    }
    else
        return super.onOptionsItemSelected(item); 
}
@Override
 public boolean onPrepareOptionsMenu(android.view.Menu menu) {
    super.onPrepareOptionsMenu(menu);
    processBA.runHook("onprepareoptionsmenu", this, new Object[] {menu});
    return true;
    
 }
 protected void onStart() {
    super.onStart();
    processBA.runHook("onstart", this, null);
}
 protected void onStop() {
    super.onStop();
    processBA.runHook("onstop", this, null);
}
    public void onWindowFocusChanged(boolean hasFocus) {
       super.onWindowFocusChanged(hasFocus);
       if (processBA.subExists("activity_windowfocuschanged"))
           processBA.raiseEvent2(null, true, "activity_windowfocuschanged", false, hasFocus);
    }
	private class B4AMenuItemsClickListener implements android.view.MenuItem.OnMenuItemClickListener {
		private final String eventName;
		public B4AMenuItemsClickListener(String eventName) {
			this.eventName = eventName;
		}
		public boolean onMenuItemClick(android.view.MenuItem item) {
			processBA.raiseEventFromUI(item.getTitle(), eventName + "_click");
			return true;
		}
	}
    public static Class<?> getObject() {
		return main.class;
	}
    private Boolean onKeySubExist = null;
    private Boolean onKeyUpSubExist = null;
	@Override
	public boolean onKeyDown(int keyCode, android.view.KeyEvent event) {
        if (processBA.runHook("onkeydown", this, new Object[] {keyCode, event}))
            return true;
		if (onKeySubExist == null)
			onKeySubExist = processBA.subExists("activity_keypress");
		if (onKeySubExist) {
			if (keyCode == anywheresoftware.b4a.keywords.constants.KeyCodes.KEYCODE_BACK &&
					android.os.Build.VERSION.SDK_INT >= 18) {
				HandleKeyDelayed hk = new HandleKeyDelayed();
				hk.kc = keyCode;
				BA.handler.post(hk);
				return true;
			}
			else {
				boolean res = new HandleKeyDelayed().runDirectly(keyCode);
				if (res)
					return true;
			}
		}
		return super.onKeyDown(keyCode, event);
	}
	private class HandleKeyDelayed implements Runnable {
		int kc;
		public void run() {
			runDirectly(kc);
		}
		public boolean runDirectly(int keyCode) {
			Boolean res =  (Boolean)processBA.raiseEvent2(_activity, false, "activity_keypress", false, keyCode);
			if (res == null || res == true) {
                return true;
            }
            else if (keyCode == anywheresoftware.b4a.keywords.constants.KeyCodes.KEYCODE_BACK) {
				finish();
				return true;
			}
            return false;
		}
		
	}
    @Override
	public boolean onKeyUp(int keyCode, android.view.KeyEvent event) {
        if (processBA.runHook("onkeyup", this, new Object[] {keyCode, event}))
            return true;
		if (onKeyUpSubExist == null)
			onKeyUpSubExist = processBA.subExists("activity_keyup");
		if (onKeyUpSubExist) {
			Boolean res =  (Boolean)processBA.raiseEvent2(_activity, false, "activity_keyup", false, keyCode);
			if (res == null || res == true)
				return true;
		}
		return super.onKeyUp(keyCode, event);
	}
	@Override
	public void onNewIntent(android.content.Intent intent) {
        super.onNewIntent(intent);
		this.setIntent(intent);
        processBA.runHook("onnewintent", this, new Object[] {intent});
	}
    @Override 
	public void onPause() {
		super.onPause();
        if (_activity == null)
            return;
        if (this != mostCurrent)
			return;
		anywheresoftware.b4a.Msgbox.dismiss(true);
        if (!dontPause)
            BA.LogInfo("** Activity (main) Pause, UserClosed = " + activityBA.activity.isFinishing() + " **");
        else
            BA.LogInfo("** Activity (main) Pause event (activity is not paused). **");
        if (mostCurrent != null)
            processBA.raiseEvent2(_activity, true, "activity_pause", false, activityBA.activity.isFinishing());		
        if (!dontPause) {
            processBA.setActivityPaused(true);
            mostCurrent = null;
        }

        if (!activityBA.activity.isFinishing())
			previousOne = new WeakReference<Activity>(this);
        anywheresoftware.b4a.Msgbox.isDismissing = false;
        processBA.runHook("onpause", this, null);
	}

	@Override
	public void onDestroy() {
        super.onDestroy();
		previousOne = null;
        processBA.runHook("ondestroy", this, null);
	}
    @Override 
	public void onResume() {
		super.onResume();
        mostCurrent = this;
        anywheresoftware.b4a.Msgbox.isDismissing = false;
        if (activityBA != null) { //will be null during activity create (which waits for AfterLayout).
        	ResumeMessage rm = new ResumeMessage(mostCurrent);
        	BA.handler.post(rm);
        }
        processBA.runHook("onresume", this, null);
	}
    private static class ResumeMessage implements Runnable {
    	private final WeakReference<Activity> activity;
    	public ResumeMessage(Activity activity) {
    		this.activity = new WeakReference<Activity>(activity);
    	}
		public void run() {
            main mc = mostCurrent;
			if (mc == null || mc != activity.get())
				return;
			processBA.setActivityPaused(false);
            BA.LogInfo("** Activity (main) Resume **");
            if (mc != mostCurrent)
                return;
		    processBA.raiseEvent(mc._activity, "activity_resume", (Object[])null);
		}
    }
	@Override
	protected void onActivityResult(int requestCode, int resultCode,
	      android.content.Intent data) {
		processBA.onActivityResult(requestCode, resultCode, data);
        processBA.runHook("onactivityresult", this, new Object[] {requestCode, resultCode});
	}
	private static void initializeGlobals() {
		processBA.raiseEvent2(null, true, "globals", false, (Object[])null);
	}
    public void onRequestPermissionsResult(int requestCode,
        String permissions[], int[] grantResults) {
        for (int i = 0;i < permissions.length;i++) {
            Object[] o = new Object[] {permissions[i], grantResults[i] == 0};
            processBA.raiseEventFromDifferentThread(null,null, 0, "activity_permissionresult", true, o);
        }
            
    }

public anywheresoftware.b4a.keywords.Common __c = null;
public static anywheresoftware.b4a.objects.Serial.BluetoothAdmin _admin = null;
public static anywheresoftware.b4a.objects.collections.List _btdevices = null;
public static boolean _searchinprogress = false;
public static String _ip = "";
public anywheresoftware.b4a.objects.ButtonWrapper _btnconnectwifi = null;
public anywheresoftware.b4a.objects.LabelWrapper _lblip = null;
public anywheresoftware.b4a.objects.SpinnerWrapper _spnrpaireddevices = null;
public anywheresoftware.b4a.objects.EditTextWrapper _edtip = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btnconnectbt = null;
public anywheresoftware.b4a.objects.LabelWrapper _lblwifistatus = null;
public anywheresoftware.b4a.objects.LabelWrapper _lblbtstatus = null;
public anywheresoftware.b4a.objects.IME _ime = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btnmakediscoverable = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btnbtsearch = null;
public anywheresoftware.b4a.objects.LabelWrapper _lblptt = null;
public b4a.example.walkietalkie.connector _connector = null;

public static boolean isAnyActivityVisible() {
    boolean vis = false;
vis = vis | (main.mostCurrent != null);
return vis;}
public static class _nameandmac{
public boolean IsInitialized;
public String name;
public String mac;
public void Initialize() {
IsInitialized = true;
name = "";
mac = "";
}
@Override
		public String toString() {
			return BA.TypeToString(this, false);
		}}
public static String  _activity_create(boolean _firsttime) throws Exception{
anywheresoftware.b4a.objects.Serial _serial1 = null;
anywheresoftware.b4a.objects.collections.Map _paireddevices = null;
int _i = 0;
b4a.example.walkietalkie.main._nameandmac _nm = null;
 //BA.debugLineNum = 37;BA.debugLine="Sub Activity_Create(FirstTime As Boolean)";
 //BA.debugLineNum = 38;BA.debugLine="If FirstTime Then";
if (_firsttime) { 
 //BA.debugLineNum = 39;BA.debugLine="StartService(Connector)";
anywheresoftware.b4a.keywords.Common.StartService(processBA,(Object)(mostCurrent._connector.getObject()));
 //BA.debugLineNum = 40;BA.debugLine="btDevices.Initialize";
_btdevices.Initialize();
 //BA.debugLineNum = 41;BA.debugLine="admin.Initialize(\"Admin\")";
_admin.Initialize(processBA,"Admin");
 //BA.debugLineNum = 45;BA.debugLine="Dim serial1 As Serial";
_serial1 = new anywheresoftware.b4a.objects.Serial();
 //BA.debugLineNum = 46;BA.debugLine="serial1.Initialize(\"\")";
_serial1.Initialize("");
 //BA.debugLineNum = 47;BA.debugLine="Dim pairedDevices As Map = serial1.GetPairedDevi";
_paireddevices = new anywheresoftware.b4a.objects.collections.Map();
_paireddevices = _serial1.GetPairedDevices();
 //BA.debugLineNum = 48;BA.debugLine="For i = 0 To pairedDevices.Size - 1";
{
final int step8 = 1;
final int limit8 = (int) (_paireddevices.getSize()-1);
_i = (int) (0) ;
for (;_i <= limit8 ;_i = _i + step8 ) {
 //BA.debugLineNum = 49;BA.debugLine="Dim nm As NameAndMac";
_nm = new b4a.example.walkietalkie.main._nameandmac();
 //BA.debugLineNum = 50;BA.debugLine="nm.Initialize";
_nm.Initialize();
 //BA.debugLineNum = 51;BA.debugLine="nm.mac = pairedDevices.GetValueAt(i)";
_nm.mac /*String*/  = BA.ObjectToString(_paireddevices.GetValueAt(_i));
 //BA.debugLineNum = 52;BA.debugLine="nm.name = pairedDevices.GetKeyAt(i)";
_nm.name /*String*/  = BA.ObjectToString(_paireddevices.GetKeyAt(_i));
 //BA.debugLineNum = 53;BA.debugLine="btDevices.Add(nm)";
_btdevices.Add((Object)(_nm));
 }
};
 };
 //BA.debugLineNum = 56;BA.debugLine="IME.Initialize(\"\")";
mostCurrent._ime.Initialize("");
 //BA.debugLineNum = 57;BA.debugLine="Activity.LoadLayout(\"1\")";
mostCurrent._activity.LoadLayout("1",mostCurrent.activityBA);
 //BA.debugLineNum = 58;BA.debugLine="Activity.AddMenuItem(\"Disconnect\", \"mnuDisconnect";
mostCurrent._activity.AddMenuItem(BA.ObjectToCharSequence("Disconnect"),"mnuDisconnect");
 //BA.debugLineNum = 60;BA.debugLine="IME.SetCustomFilter(edtIP, edtIP.INPUT_TYPE_DECIM";
mostCurrent._ime.SetCustomFilter((android.widget.EditText)(mostCurrent._edtip.getObject()),mostCurrent._edtip.INPUT_TYPE_DECIMAL_NUMBERS,"0123456789.");
 //BA.debugLineNum = 61;BA.debugLine="End Sub";
return "";
}
public static String  _activity_pause(boolean _userclosed) throws Exception{
 //BA.debugLineNum = 87;BA.debugLine="Sub Activity_Pause (UserClosed As Boolean)";
 //BA.debugLineNum = 89;BA.debugLine="ip = edtIP.Text";
_ip = mostCurrent._edtip.getText();
 //BA.debugLineNum = 90;BA.debugLine="End Sub";
return "";
}
public static String  _activity_resume() throws Exception{
b4a.example.walkietalkie.main._nameandmac _nm = null;
 //BA.debugLineNum = 63;BA.debugLine="Sub Activity_Resume";
 //BA.debugLineNum = 64;BA.debugLine="edtIP.Text = ip";
mostCurrent._edtip.setText(BA.ObjectToCharSequence(_ip));
 //BA.debugLineNum = 65;BA.debugLine="spnrPairedDevices.Clear";
mostCurrent._spnrpaireddevices.Clear();
 //BA.debugLineNum = 66;BA.debugLine="For Each nm As NameAndMac In btDevices";
{
final anywheresoftware.b4a.BA.IterableList group3 = _btdevices;
final int groupLen3 = group3.getSize()
;int index3 = 0;
;
for (; index3 < groupLen3;index3++){
_nm = (b4a.example.walkietalkie.main._nameandmac)(group3.Get(index3));
 //BA.debugLineNum = 67;BA.debugLine="spnrPairedDevices.Add(nm.name)";
mostCurrent._spnrpaireddevices.Add(_nm.name /*String*/ );
 }
};
 //BA.debugLineNum = 70;BA.debugLine="If admin.IsEnabled = False Then";
if (_admin.IsEnabled()==anywheresoftware.b4a.keywords.Common.False) { 
 //BA.debugLineNum = 71;BA.debugLine="If admin.Enable = False Then";
if (_admin.Enable()==anywheresoftware.b4a.keywords.Common.False) { 
 //BA.debugLineNum = 72;BA.debugLine="ToastMessageShow(\"Error enabling Bluetooth adap";
anywheresoftware.b4a.keywords.Common.ToastMessageShow(BA.ObjectToCharSequence("Error enabling Bluetooth adapter."),anywheresoftware.b4a.keywords.Common.True);
 }else {
 //BA.debugLineNum = 74;BA.debugLine="ToastMessageShow(\"Enabling Bluetooth adapter...";
anywheresoftware.b4a.keywords.Common.ToastMessageShow(BA.ObjectToCharSequence("Enabling Bluetooth adapter..."),anywheresoftware.b4a.keywords.Common.False);
 };
 };
 //BA.debugLineNum = 78;BA.debugLine="UpdateUI";
_updateui();
 //BA.debugLineNum = 79;BA.debugLine="End Sub";
return "";
}
public static String  _activity_touch(int _action,float _x,float _y) throws Exception{
 //BA.debugLineNum = 191;BA.debugLine="Sub Activity_Touch (Action As Int, X As Float, Y A";
 //BA.debugLineNum = 192;BA.debugLine="If Connector.BTConnected = False And Connector.Wi";
if (mostCurrent._connector._btconnected /*boolean*/ ==anywheresoftware.b4a.keywords.Common.False && mostCurrent._connector._wificonnected /*boolean*/ ==anywheresoftware.b4a.keywords.Common.False) { 
if (true) return "";};
 //BA.debugLineNum = 193;BA.debugLine="If Action = Activity.ACTION_DOWN Then";
if (_action==mostCurrent._activity.ACTION_DOWN) { 
 //BA.debugLineNum = 194;BA.debugLine="Activity.Color = Colors.Red";
mostCurrent._activity.setColor(anywheresoftware.b4a.keywords.Common.Colors.Red);
 //BA.debugLineNum = 195;BA.debugLine="CallSub(Connector, \"SendAudio\")";
anywheresoftware.b4a.keywords.Common.CallSubNew(processBA,(Object)(mostCurrent._connector.getObject()),"SendAudio");
 }else if(_action==mostCurrent._activity.ACTION_UP) { 
 //BA.debugLineNum = 197;BA.debugLine="Activity.Color = Colors.Black";
mostCurrent._activity.setColor(anywheresoftware.b4a.keywords.Common.Colors.Black);
 //BA.debugLineNum = 198;BA.debugLine="CallSub(Connector, \"StopSendingAudio\")";
anywheresoftware.b4a.keywords.Common.CallSubNew(processBA,(Object)(mostCurrent._connector.getObject()),"StopSendingAudio");
 };
 //BA.debugLineNum = 200;BA.debugLine="End Sub";
return "";
}
public static String  _admin_devicefound(String _name,String _macaddress) throws Exception{
b4a.example.walkietalkie.main._nameandmac _nm = null;
 //BA.debugLineNum = 167;BA.debugLine="Sub Admin_DeviceFound (Name As String, MacAddress";
 //BA.debugLineNum = 168;BA.debugLine="Log(Name & \":\" & MacAddress)";
anywheresoftware.b4a.keywords.Common.LogImpl("4851969",_name+":"+_macaddress,0);
 //BA.debugLineNum = 169;BA.debugLine="spnrPairedDevices.Add(Name)";
mostCurrent._spnrpaireddevices.Add(_name);
 //BA.debugLineNum = 170;BA.debugLine="Dim nm As NameAndMac";
_nm = new b4a.example.walkietalkie.main._nameandmac();
 //BA.debugLineNum = 171;BA.debugLine="nm.Initialize";
_nm.Initialize();
 //BA.debugLineNum = 172;BA.debugLine="nm.Name = Name";
_nm.name /*String*/  = _name;
 //BA.debugLineNum = 173;BA.debugLine="nm.mac = MacAddress";
_nm.mac /*String*/  = _macaddress;
 //BA.debugLineNum = 174;BA.debugLine="btDevices.Add(nm)";
_btdevices.Add((Object)(_nm));
 //BA.debugLineNum = 175;BA.debugLine="SetBTStatus(\"Searching for devices (\" & btDevices";
_setbtstatus("Searching for devices ("+BA.NumberToString(_btdevices.getSize())+" found)");
 //BA.debugLineNum = 176;BA.debugLine="End Sub";
return "";
}
public static String  _admin_discoveryfinished() throws Exception{
 //BA.debugLineNum = 157;BA.debugLine="Sub Admin_DiscoveryFinished";
 //BA.debugLineNum = 158;BA.debugLine="searchInProgress = False";
_searchinprogress = anywheresoftware.b4a.keywords.Common.False;
 //BA.debugLineNum = 159;BA.debugLine="If spnrPairedDevices.Size = 0 Then";
if (mostCurrent._spnrpaireddevices.getSize()==0) { 
 //BA.debugLineNum = 160;BA.debugLine="SetBTStatus(\"No BT devices found.\")";
_setbtstatus("No BT devices found.");
 }else {
 //BA.debugLineNum = 162;BA.debugLine="SetBTStatus(spnrPairedDevices.Size & \" device(s)";
_setbtstatus(BA.NumberToString(mostCurrent._spnrpaireddevices.getSize())+" device(s) found.");
 };
 //BA.debugLineNum = 164;BA.debugLine="UpdateUI";
_updateui();
 //BA.debugLineNum = 165;BA.debugLine="End Sub";
return "";
}
public static String  _admin_statechanged(int _newstate,int _oldstate) throws Exception{
 //BA.debugLineNum = 92;BA.debugLine="Sub Admin_StateChanged (NewState As Int, OldState";
 //BA.debugLineNum = 93;BA.debugLine="UpdateUI";
_updateui();
 //BA.debugLineNum = 94;BA.debugLine="End Sub";
return "";
}
public static String  _btnbtsearch_click() throws Exception{
 //BA.debugLineNum = 140;BA.debugLine="Sub btnBTSearch_Click";
 //BA.debugLineNum = 141;BA.debugLine="spnrPairedDevices.Clear";
mostCurrent._spnrpaireddevices.Clear();
 //BA.debugLineNum = 142;BA.debugLine="btDevices.Clear";
_btdevices.Clear();
 //BA.debugLineNum = 143;BA.debugLine="If admin.StartDiscovery	= False Then";
if (_admin.StartDiscovery()==anywheresoftware.b4a.keywords.Common.False) { 
 //BA.debugLineNum = 144;BA.debugLine="ToastMessageShow(\"Error starting discovery proce";
anywheresoftware.b4a.keywords.Common.ToastMessageShow(BA.ObjectToCharSequence("Error starting discovery process."),anywheresoftware.b4a.keywords.Common.True);
 }else {
 //BA.debugLineNum = 146;BA.debugLine="searchInProgress = True";
_searchinprogress = anywheresoftware.b4a.keywords.Common.True;
 //BA.debugLineNum = 147;BA.debugLine="SetBTStatus(\"Searching for BT devices...\")";
_setbtstatus("Searching for BT devices...");
 //BA.debugLineNum = 148;BA.debugLine="UpdateUI";
_updateui();
 };
 //BA.debugLineNum = 150;BA.debugLine="End Sub";
return "";
}
public static String  _btnconnectbt_click() throws Exception{
b4a.example.walkietalkie.main._nameandmac _nm = null;
 //BA.debugLineNum = 133;BA.debugLine="Sub btnConnectBT_Click";
 //BA.debugLineNum = 134;BA.debugLine="If spnrPairedDevices.SelectedIndex = -1 Then Retu";
if (mostCurrent._spnrpaireddevices.getSelectedIndex()==-1) { 
if (true) return "";};
 //BA.debugLineNum = 135;BA.debugLine="Dim nm As NameAndMac = btDevices.Get(spnrPairedDe";
_nm = (b4a.example.walkietalkie.main._nameandmac)(_btdevices.Get(mostCurrent._spnrpaireddevices.getSelectedIndex()));
 //BA.debugLineNum = 136;BA.debugLine="CallSubDelayed2(Connector, \"ConnectBT\", nm.mac)";
anywheresoftware.b4a.keywords.Common.CallSubDelayed2(processBA,(Object)(mostCurrent._connector.getObject()),"ConnectBT",(Object)(_nm.mac /*String*/ ));
 //BA.debugLineNum = 137;BA.debugLine="End Sub";
return "";
}
public static String  _btnconnectwifi_click() throws Exception{
 //BA.debugLineNum = 129;BA.debugLine="Sub btnConnectWifi_Click";
 //BA.debugLineNum = 130;BA.debugLine="CallSubDelayed2(Connector, \"ConnectWifi\", edtIP.T";
anywheresoftware.b4a.keywords.Common.CallSubDelayed2(processBA,(Object)(mostCurrent._connector.getObject()),"ConnectWifi",(Object)(mostCurrent._edtip.getText()));
 //BA.debugLineNum = 131;BA.debugLine="End Sub";
return "";
}
public static String  _btnmakediscoverable_click() throws Exception{
anywheresoftware.b4a.objects.IntentWrapper _i = null;
 //BA.debugLineNum = 178;BA.debugLine="Sub btnMakeDiscoverable_Click";
 //BA.debugLineNum = 180;BA.debugLine="Dim i As Intent";
_i = new anywheresoftware.b4a.objects.IntentWrapper();
 //BA.debugLineNum = 181;BA.debugLine="i.Initialize(\"android.bluetooth.adapter.action.RE";
_i.Initialize("android.bluetooth.adapter.action.REQUEST_DISCOVERABLE","");
 //BA.debugLineNum = 182;BA.debugLine="i.PutExtra(\"android.bluetooth.adapter.extra.DISCO";
_i.PutExtra("android.bluetooth.adapter.extra.DISCOVERABLE_DURATION",(Object)(300));
 //BA.debugLineNum = 183;BA.debugLine="StartActivity(i)";
anywheresoftware.b4a.keywords.Common.StartActivity(processBA,(Object)(_i.getObject()));
 //BA.debugLineNum = 184;BA.debugLine="End Sub";
return "";
}
public static String  _edtip_textchanged(String _old,String _new) throws Exception{
 //BA.debugLineNum = 186;BA.debugLine="Sub edtIP_TextChanged (Old As String, New As Strin";
 //BA.debugLineNum = 187;BA.debugLine="UpdateUI 'the btnConnectWifi.Enabled depends on t";
_updateui();
 //BA.debugLineNum = 188;BA.debugLine="End Sub";
return "";
}
public static String  _globals() throws Exception{
 //BA.debugLineNum = 23;BA.debugLine="Sub Globals";
 //BA.debugLineNum = 24;BA.debugLine="Dim btnConnectWifi As Button";
mostCurrent._btnconnectwifi = new anywheresoftware.b4a.objects.ButtonWrapper();
 //BA.debugLineNum = 25;BA.debugLine="Dim lblIP As Label";
mostCurrent._lblip = new anywheresoftware.b4a.objects.LabelWrapper();
 //BA.debugLineNum = 26;BA.debugLine="Dim spnrPairedDevices As Spinner";
mostCurrent._spnrpaireddevices = new anywheresoftware.b4a.objects.SpinnerWrapper();
 //BA.debugLineNum = 27;BA.debugLine="Dim edtIP As EditText";
mostCurrent._edtip = new anywheresoftware.b4a.objects.EditTextWrapper();
 //BA.debugLineNum = 28;BA.debugLine="Dim btnConnectBT As Button";
mostCurrent._btnconnectbt = new anywheresoftware.b4a.objects.ButtonWrapper();
 //BA.debugLineNum = 29;BA.debugLine="Dim lblWifiStatus As Label";
mostCurrent._lblwifistatus = new anywheresoftware.b4a.objects.LabelWrapper();
 //BA.debugLineNum = 30;BA.debugLine="Dim lblBTStatus As Label";
mostCurrent._lblbtstatus = new anywheresoftware.b4a.objects.LabelWrapper();
 //BA.debugLineNum = 31;BA.debugLine="Dim IME As IME";
mostCurrent._ime = new anywheresoftware.b4a.objects.IME();
 //BA.debugLineNum = 32;BA.debugLine="Dim btnMakeDiscoverable As Button";
mostCurrent._btnmakediscoverable = new anywheresoftware.b4a.objects.ButtonWrapper();
 //BA.debugLineNum = 33;BA.debugLine="Dim btnBTSearch As Button";
mostCurrent._btnbtsearch = new anywheresoftware.b4a.objects.ButtonWrapper();
 //BA.debugLineNum = 34;BA.debugLine="Dim lblPTT As Label";
mostCurrent._lblptt = new anywheresoftware.b4a.objects.LabelWrapper();
 //BA.debugLineNum = 35;BA.debugLine="End Sub";
return "";
}
public static String  _mnudisconnect_click() throws Exception{
 //BA.debugLineNum = 81;BA.debugLine="Sub mnuDisconnect_Click";
 //BA.debugLineNum = 82;BA.debugLine="CallSub(Connector, \"Disconnect\")";
anywheresoftware.b4a.keywords.Common.CallSubNew(processBA,(Object)(mostCurrent._connector.getObject()),"Disconnect");
 //BA.debugLineNum = 83;BA.debugLine="End Sub";
return "";
}

public static void initializeProcessGlobals() {
    
    if (main.processGlobalsRun == false) {
	    main.processGlobalsRun = true;
		try {
		        main._process_globals();
connector._process_globals();
		
        } catch (Exception e) {
			throw new RuntimeException(e);
		}
    }
}public static String  _process_globals() throws Exception{
 //BA.debugLineNum = 15;BA.debugLine="Sub Process_Globals";
 //BA.debugLineNum = 16;BA.debugLine="Private admin As BluetoothAdmin";
_admin = new anywheresoftware.b4a.objects.Serial.BluetoothAdmin();
 //BA.debugLineNum = 17;BA.debugLine="Private btDevices As List";
_btdevices = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 18;BA.debugLine="Type NameAndMac (name As String, mac As String)";
;
 //BA.debugLineNum = 19;BA.debugLine="Private searchInProgress As Boolean";
_searchinprogress = false;
 //BA.debugLineNum = 20;BA.debugLine="Private ip As String";
_ip = "";
 //BA.debugLineNum = 21;BA.debugLine="End Sub";
return "";
}
public static String  _setbtstatus(String _status) throws Exception{
 //BA.debugLineNum = 152;BA.debugLine="Sub SetBTStatus(status As String)";
 //BA.debugLineNum = 153;BA.debugLine="Connector.BTstatus = status";
mostCurrent._connector._btstatus /*String*/  = _status;
 //BA.debugLineNum = 154;BA.debugLine="lblBTStatus.Text = status";
mostCurrent._lblbtstatus.setText(BA.ObjectToCharSequence(_status));
 //BA.debugLineNum = 155;BA.debugLine="End Sub";
return "";
}
public static String  _updateui() throws Exception{
boolean _wifi = false;
boolean _bt = false;
boolean _discover = false;
 //BA.debugLineNum = 96;BA.debugLine="Public Sub UpdateUI";
 //BA.debugLineNum = 98;BA.debugLine="Dim wifi = True, bt = True, discover = True As Bo";
_wifi = anywheresoftware.b4a.keywords.Common.True;
_bt = anywheresoftware.b4a.keywords.Common.True;
_discover = anywheresoftware.b4a.keywords.Common.True;
 //BA.debugLineNum = 99;BA.debugLine="If admin.IsEnabled = False Then";
if (_admin.IsEnabled()==anywheresoftware.b4a.keywords.Common.False) { 
 //BA.debugLineNum = 100;BA.debugLine="bt = False";
_bt = anywheresoftware.b4a.keywords.Common.False;
 //BA.debugLineNum = 101;BA.debugLine="discover = False";
_discover = anywheresoftware.b4a.keywords.Common.False;
 };
 //BA.debugLineNum = 103;BA.debugLine="lblIP.Text = Connector.MyIP";
mostCurrent._lblip.setText(BA.ObjectToCharSequence(mostCurrent._connector._myip /*String*/ ));
 //BA.debugLineNum = 104;BA.debugLine="lblWifiStatus.Text = Connector.WifiStatus";
mostCurrent._lblwifistatus.setText(BA.ObjectToCharSequence(mostCurrent._connector._wifistatus /*String*/ ));
 //BA.debugLineNum = 105;BA.debugLine="lblBTStatus.Text = Connector.BTStatus";
mostCurrent._lblbtstatus.setText(BA.ObjectToCharSequence(mostCurrent._connector._btstatus /*String*/ ));
 //BA.debugLineNum = 106;BA.debugLine="If Connector.WifiConnected Then lblWifiStatus.Tex";
if (mostCurrent._connector._wificonnected /*boolean*/ ) { 
mostCurrent._lblwifistatus.setTextColor(anywheresoftware.b4a.keywords.Common.Colors.Green);}
else {
mostCurrent._lblwifistatus.setTextColor(anywheresoftware.b4a.keywords.Common.Colors.Red);};
 //BA.debugLineNum = 107;BA.debugLine="If Connector.BTConnected Then lblBTStatus.TextCol";
if (mostCurrent._connector._btconnected /*boolean*/ ) { 
mostCurrent._lblbtstatus.setTextColor(anywheresoftware.b4a.keywords.Common.Colors.Green);}
else {
mostCurrent._lblbtstatus.setTextColor(anywheresoftware.b4a.keywords.Common.Colors.Red);};
 //BA.debugLineNum = 108;BA.debugLine="If spnrPairedDevices.Size = 0 Then bt = False";
if (mostCurrent._spnrpaireddevices.getSize()==0) { 
_bt = anywheresoftware.b4a.keywords.Common.False;};
 //BA.debugLineNum = 109;BA.debugLine="If Connector.BTConnected Or Connector.WifiConnect";
if (mostCurrent._connector._btconnected /*boolean*/  || mostCurrent._connector._wificonnected /*boolean*/ ) { 
 //BA.debugLineNum = 110;BA.debugLine="wifi = False";
_wifi = anywheresoftware.b4a.keywords.Common.False;
 //BA.debugLineNum = 111;BA.debugLine="bt = False";
_bt = anywheresoftware.b4a.keywords.Common.False;
 //BA.debugLineNum = 112;BA.debugLine="discover = False";
_discover = anywheresoftware.b4a.keywords.Common.False;
 };
 //BA.debugLineNum = 115;BA.debugLine="If wifi And Regex.IsMatch(\"[^.]+\\.[^.]+\\.[^.]+\\.[";
if (_wifi && anywheresoftware.b4a.keywords.Common.Regex.IsMatch("[^.]+\\.[^.]+\\.[^.]+\\.[^.]+",mostCurrent._edtip.getText())==anywheresoftware.b4a.keywords.Common.False) { 
 //BA.debugLineNum = 116;BA.debugLine="wifi = False";
_wifi = anywheresoftware.b4a.keywords.Common.False;
 };
 //BA.debugLineNum = 121;BA.debugLine="If searchInProgress Then bt = False";
if (_searchinprogress) { 
_bt = anywheresoftware.b4a.keywords.Common.False;};
 //BA.debugLineNum = 122;BA.debugLine="btnConnectBT.Enabled = bt";
mostCurrent._btnconnectbt.setEnabled(_bt);
 //BA.debugLineNum = 123;BA.debugLine="btnConnectWifi.Enabled = wifi";
mostCurrent._btnconnectwifi.setEnabled(_wifi);
 //BA.debugLineNum = 124;BA.debugLine="btnBTSearch.Enabled = discover";
mostCurrent._btnbtsearch.setEnabled(_discover);
 //BA.debugLineNum = 125;BA.debugLine="btnMakeDiscoverable.Enabled = discover";
mostCurrent._btnmakediscoverable.setEnabled(_discover);
 //BA.debugLineNum = 126;BA.debugLine="lblPTT.Visible = Connector.BTConnected Or Connect";
mostCurrent._lblptt.setVisible(mostCurrent._connector._btconnected /*boolean*/  || mostCurrent._connector._wificonnected /*boolean*/ );
 //BA.debugLineNum = 127;BA.debugLine="End Sub";
return "";
}
}
