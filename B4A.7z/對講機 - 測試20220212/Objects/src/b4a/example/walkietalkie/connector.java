package b4a.example.walkietalkie;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.objects.ServiceHelper;
import anywheresoftware.b4a.debug.*;

public class connector extends  android.app.Service{
	public static class connector_BR extends android.content.BroadcastReceiver {

		@Override
		public void onReceive(android.content.Context context, android.content.Intent intent) {
            BA.LogInfo("** Receiver (connector) OnReceive **");
			android.content.Intent in = new android.content.Intent(context, connector.class);
			if (intent != null)
				in.putExtra("b4a_internal_intent", intent);
            ServiceHelper.StarterHelper.startServiceFromReceiver (context, in, false, BA.class);
		}

	}
    static connector mostCurrent;
	public static BA processBA;
    private ServiceHelper _service;
    public static Class<?> getObject() {
		return connector.class;
	}
	@Override
	public void onCreate() {
        super.onCreate();
        mostCurrent = this;
        if (processBA == null) {
		    processBA = new BA(this, null, null, "b4a.example.walkietalkie", "b4a.example.walkietalkie.connector");
            if (BA.isShellModeRuntimeCheck(processBA)) {
                processBA.raiseEvent2(null, true, "SHELL", false);
		    }
            try {
                Class.forName(BA.applicationContext.getPackageName() + ".main").getMethod("initializeProcessGlobals").invoke(null, null);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
            processBA.loadHtSubs(this.getClass());
            ServiceHelper.init();
        }
        _service = new ServiceHelper(this);
        processBA.service = this;
        
        if (BA.isShellModeRuntimeCheck(processBA)) {
			processBA.raiseEvent2(null, true, "CREATE", true, "b4a.example.walkietalkie.connector", processBA, _service, anywheresoftware.b4a.keywords.Common.Density);
		}
        if (!false && ServiceHelper.StarterHelper.startFromServiceCreate(processBA, true) == false) {
				
		}
		else {
            processBA.setActivityPaused(false);
            BA.LogInfo("*** Service (connector) Create ***");
            processBA.raiseEvent(null, "service_create");
        }
        processBA.runHook("oncreate", this, null);
        if (false) {
			ServiceHelper.StarterHelper.runWaitForLayouts();
		}
    }
		@Override
	public void onStart(android.content.Intent intent, int startId) {
		onStartCommand(intent, 0, 0);
    }
    @Override
    public int onStartCommand(final android.content.Intent intent, int flags, int startId) {
    	if (ServiceHelper.StarterHelper.onStartCommand(processBA, new Runnable() {
            public void run() {
                handleStart(intent);
            }}))
			;
		else {
			ServiceHelper.StarterHelper.addWaitForLayout (new Runnable() {
				public void run() {
                    processBA.setActivityPaused(false);
                    BA.LogInfo("** Service (connector) Create **");
                    processBA.raiseEvent(null, "service_create");
					handleStart(intent);
                    ServiceHelper.StarterHelper.removeWaitForLayout();
				}
			});
		}
        processBA.runHook("onstartcommand", this, new Object[] {intent, flags, startId});
		return android.app.Service.START_NOT_STICKY;
    }
    public void onTaskRemoved(android.content.Intent rootIntent) {
        super.onTaskRemoved(rootIntent);
        if (false)
            processBA.raiseEvent(null, "service_taskremoved");
            
    }
    private void handleStart(android.content.Intent intent) {
    	BA.LogInfo("** Service (connector) Start **");
    	java.lang.reflect.Method startEvent = processBA.htSubs.get("service_start");
    	if (startEvent != null) {
    		if (startEvent.getParameterTypes().length > 0) {
    			anywheresoftware.b4a.objects.IntentWrapper iw = ServiceHelper.StarterHelper.handleStartIntent(intent, _service, processBA);
    			processBA.raiseEvent(null, "service_start", iw);
    		}
    		else {
    			processBA.raiseEvent(null, "service_start");
    		}
    	}
    }
	
	@Override
	public void onDestroy() {
        super.onDestroy();
        if (false) {
            BA.LogInfo("** Service (connector) Destroy (ignored)**");
        }
        else {
            BA.LogInfo("** Service (connector) Destroy **");
		    processBA.raiseEvent(null, "service_destroy");
            processBA.service = null;
		    mostCurrent = null;
		    processBA.setActivityPaused(true);
            processBA.runHook("ondestroy", this, null);
        }
	}

@Override
	public android.os.IBinder onBind(android.content.Intent intent) {
		return null;
	}public anywheresoftware.b4a.keywords.Common __c = null;
public static String _myip = "";
public static String _wifistatus = "";
public static String _btstatus = "";
public static boolean _wificonnected = false;
public static boolean _btconnected = false;
public static anywheresoftware.b4a.objects.Serial.BluetoothAdmin _admin = null;
public static anywheresoftware.b4a.objects.Serial _serial1 = null;
public static anywheresoftware.b4a.objects.SocketWrapper _socket1 = null;
public static anywheresoftware.b4a.objects.SocketWrapper.ServerSocketWrapper _server = null;
public static int _port = 0;
public static String _uuid = "";
public static anywheresoftware.b4a.randomaccessfile.AsyncStreams _astream = null;
public static anywheresoftware.b4a.phone.PhoneEvents _pe = null;
public static anywheresoftware.b4a.audio.AudioStreamer _audiostream = null;
public static boolean _sendingaudio = false;
public b4a.example.walkietalkie.main _main = null;
public static String  _admin_statechanged(int _newstate,int _oldstate) throws Exception{
 //BA.debugLineNum = 39;BA.debugLine="Sub admin_StateChanged (NewState As Int, OldState";
 //BA.debugLineNum = 40;BA.debugLine="If NewState = admin.STATE_ON Then serial1.Listen2";
if (_newstate==_admin.STATE_ON) { 
_serial1.Listen2("na",_uuid,processBA);};
 //BA.debugLineNum = 41;BA.debugLine="End Sub";
return "";
}
public static String  _astream_error() throws Exception{
 //BA.debugLineNum = 144;BA.debugLine="Sub Astream_Error";
 //BA.debugLineNum = 145;BA.debugLine="Log(\"Error: \" & LastException)";
anywheresoftware.b4a.keywords.Common.LogImpl("42228225","Error: "+BA.ObjectToString(anywheresoftware.b4a.keywords.Common.LastException(processBA)),0);
 //BA.debugLineNum = 146;BA.debugLine="astream.Close";
_astream.Close();
 //BA.debugLineNum = 147;BA.debugLine="AStream_Terminated 'manually call this method as";
_astream_terminated();
 //BA.debugLineNum = 149;BA.debugLine="End Sub";
return "";
}
public static String  _astream_newdata(byte[] _buffer) throws Exception{
 //BA.debugLineNum = 136;BA.debugLine="Sub astream_NewData (Buffer() As Byte)";
 //BA.debugLineNum = 137;BA.debugLine="If sendingAudio = False Then";
if (_sendingaudio==anywheresoftware.b4a.keywords.Common.False) { 
 //BA.debugLineNum = 139;BA.debugLine="audioStream.Write(Buffer)";
_audiostream.Write(_buffer);
 };
 //BA.debugLineNum = 141;BA.debugLine="End Sub";
return "";
}
public static String  _astream_terminated() throws Exception{
 //BA.debugLineNum = 151;BA.debugLine="Sub AStream_Terminated";
 //BA.debugLineNum = 152;BA.debugLine="If BTConnected Then";
if (_btconnected) { 
 //BA.debugLineNum = 153;BA.debugLine="BTStatus = \"Disconnected\"";
_btstatus = "Disconnected";
 }else if(_wificonnected) { 
 //BA.debugLineNum = 155;BA.debugLine="WifiStatus = \"Disconnected\"";
_wifistatus = "Disconnected";
 };
 //BA.debugLineNum = 157;BA.debugLine="BTConnected = False";
_btconnected = anywheresoftware.b4a.keywords.Common.False;
 //BA.debugLineNum = 158;BA.debugLine="WifiConnected = False";
_wificonnected = anywheresoftware.b4a.keywords.Common.False;
 //BA.debugLineNum = 159;BA.debugLine="audioStream.StopPlaying";
_audiostream.StopPlaying();
 //BA.debugLineNum = 160;BA.debugLine="audioStream.StopRecording";
_audiostream.StopRecording();
 //BA.debugLineNum = 161;BA.debugLine="UpdateUI";
_updateui();
 //BA.debugLineNum = 162;BA.debugLine="End Sub";
return "";
}
public static String  _audiostream_recordbuffer(byte[] _data) throws Exception{
 //BA.debugLineNum = 130;BA.debugLine="Sub AudioStream_RecordBuffer (Data() As Byte)";
 //BA.debugLineNum = 131;BA.debugLine="If sendingAudio Then";
if (_sendingaudio) { 
 //BA.debugLineNum = 132;BA.debugLine="astream.Write(Data)";
_astream.Write(_data);
 };
 //BA.debugLineNum = 134;BA.debugLine="End Sub";
return "";
}
public static String  _connectbt(String _address) throws Exception{
 //BA.debugLineNum = 61;BA.debugLine="Public Sub ConnectBT(Address As String)";
 //BA.debugLineNum = 62;BA.debugLine="serial1.Connect2(Address, uuid)";
_serial1.Connect2(processBA,_address,_uuid);
 //BA.debugLineNum = 63;BA.debugLine="BTStatus = \"Trying to connect...\"";
_btstatus = "Trying to connect...";
 //BA.debugLineNum = 64;BA.debugLine="UpdateUI";
_updateui();
 //BA.debugLineNum = 65;BA.debugLine="End Sub";
return "";
}
public static String  _connectwifi(String _ip) throws Exception{
 //BA.debugLineNum = 67;BA.debugLine="Public Sub ConnectWifi(Ip As String)";
 //BA.debugLineNum = 68;BA.debugLine="socket1.Initialize(\"socket1\")";
_socket1.Initialize("socket1");
 //BA.debugLineNum = 69;BA.debugLine="socket1.Connect(Ip, port, 30000)";
_socket1.Connect(processBA,_ip,_port,(int) (30000));
 //BA.debugLineNum = 70;BA.debugLine="WifiStatus = \"Trying to connect...\"";
_wifistatus = "Trying to connect...";
 //BA.debugLineNum = 71;BA.debugLine="UpdateUI";
_updateui();
 //BA.debugLineNum = 72;BA.debugLine="End Sub";
return "";
}
public static String  _disconnect() throws Exception{
 //BA.debugLineNum = 55;BA.debugLine="Public Sub Disconnect";
 //BA.debugLineNum = 56;BA.debugLine="If WifiConnected Or BTConnected Then";
if (_wificonnected || _btconnected) { 
 //BA.debugLineNum = 57;BA.debugLine="astream.Close";
_astream.Close();
 //BA.debugLineNum = 58;BA.debugLine="AStream_Terminated";
_astream_terminated();
 };
 //BA.debugLineNum = 60;BA.debugLine="End Sub";
return "";
}
public static String  _pe_connectivitychanged(String _networktype,String _state,anywheresoftware.b4a.objects.IntentWrapper _intent) throws Exception{
 //BA.debugLineNum = 43;BA.debugLine="Sub pe_ConnectivityChanged (NetworkType As String,";
 //BA.debugLineNum = 44;BA.debugLine="MyIP = server.GetMyWifiIP";
_myip = _server.GetMyWifiIP();
 //BA.debugLineNum = 45;BA.debugLine="UpdateUI";
_updateui();
 //BA.debugLineNum = 46;BA.debugLine="End Sub";
return "";
}
public static String  _process_globals() throws Exception{
 //BA.debugLineNum = 5;BA.debugLine="Sub Process_Globals";
 //BA.debugLineNum = 6;BA.debugLine="Public MyIP As String = \"N/A\"";
_myip = "N/A";
 //BA.debugLineNum = 7;BA.debugLine="Public WifiStatus As String = \"Disconnected\"";
_wifistatus = "Disconnected";
 //BA.debugLineNum = 8;BA.debugLine="Public BTStatus  As String = \"Disconnected\"";
_btstatus = "Disconnected";
 //BA.debugLineNum = 9;BA.debugLine="Public WifiConnected, BTConnected As Boolean";
_wificonnected = false;
_btconnected = false;
 //BA.debugLineNum = 10;BA.debugLine="Private admin As BluetoothAdmin";
_admin = new anywheresoftware.b4a.objects.Serial.BluetoothAdmin();
 //BA.debugLineNum = 11;BA.debugLine="Private serial1 As Serial";
_serial1 = new anywheresoftware.b4a.objects.Serial();
 //BA.debugLineNum = 12;BA.debugLine="Private socket1 As Socket";
_socket1 = new anywheresoftware.b4a.objects.SocketWrapper();
 //BA.debugLineNum = 13;BA.debugLine="Private server As ServerSocket";
_server = new anywheresoftware.b4a.objects.SocketWrapper.ServerSocketWrapper();
 //BA.debugLineNum = 14;BA.debugLine="Private port As Int = 21341";
_port = (int) (21341);
 //BA.debugLineNum = 15;BA.debugLine="Private uuid As String = \"dabcabcd-afac-11de-8a39";
_uuid = "dabcabcd-afac-11de-8a39-0800200c9a6";
 //BA.debugLineNum = 16;BA.debugLine="Private astream As AsyncStreams";
_astream = new anywheresoftware.b4a.randomaccessfile.AsyncStreams();
 //BA.debugLineNum = 17;BA.debugLine="Private pe As PhoneEvents";
_pe = new anywheresoftware.b4a.phone.PhoneEvents();
 //BA.debugLineNum = 18;BA.debugLine="Private audioStream As AudioStreamer";
_audiostream = new anywheresoftware.b4a.audio.AudioStreamer();
 //BA.debugLineNum = 19;BA.debugLine="Private sendingAudio As Boolean";
_sendingaudio = false;
 //BA.debugLineNum = 20;BA.debugLine="End Sub";
return "";
}
public static String  _sendaudio() throws Exception{
 //BA.debugLineNum = 119;BA.debugLine="Public Sub SendAudio";
 //BA.debugLineNum = 120;BA.debugLine="audioStream.StartRecording";
_audiostream.StartRecording();
 //BA.debugLineNum = 121;BA.debugLine="sendingAudio = True";
_sendingaudio = anywheresoftware.b4a.keywords.Common.True;
 //BA.debugLineNum = 122;BA.debugLine="End Sub";
return "";
}
public static String  _serial1_connected(boolean _success) throws Exception{
 //BA.debugLineNum = 101;BA.debugLine="Private Sub serial1_Connected (Success As Boolean)";
 //BA.debugLineNum = 102;BA.debugLine="If Success Then";
if (_success) { 
 //BA.debugLineNum = 103;BA.debugLine="BTStatus = \"Connected\"";
_btstatus = "Connected";
 //BA.debugLineNum = 104;BA.debugLine="BTConnected = True";
_btconnected = anywheresoftware.b4a.keywords.Common.True;
 //BA.debugLineNum = 105;BA.debugLine="StartAStream(serial1.InputStream, serial1.Output";
_startastream((anywheresoftware.b4a.objects.streams.File.InputStreamWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.streams.File.InputStreamWrapper(), (java.io.InputStream)(_serial1.getInputStream())),(anywheresoftware.b4a.objects.streams.File.OutputStreamWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.streams.File.OutputStreamWrapper(), (java.io.OutputStream)(_serial1.getOutputStream())));
 }else {
 //BA.debugLineNum = 107;BA.debugLine="BTStatus = \"Error: \" & LastException.Message";
_btstatus = "Error: "+anywheresoftware.b4a.keywords.Common.LastException(processBA).getMessage();
 };
 //BA.debugLineNum = 109;BA.debugLine="UpdateUI";
_updateui();
 //BA.debugLineNum = 110;BA.debugLine="End Sub";
return "";
}
public static String  _server_newconnection(boolean _successful,anywheresoftware.b4a.objects.SocketWrapper _newsocket) throws Exception{
 //BA.debugLineNum = 88;BA.debugLine="Private Sub server_NewConnection (Successful As Bo";
 //BA.debugLineNum = 90;BA.debugLine="If Successful Then";
if (_successful) { 
 //BA.debugLineNum = 91;BA.debugLine="WifiConnected = True";
_wificonnected = anywheresoftware.b4a.keywords.Common.True;
 //BA.debugLineNum = 92;BA.debugLine="StartAStream(NewSocket.InputStream, NewSocket.Ou";
_startastream((anywheresoftware.b4a.objects.streams.File.InputStreamWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.streams.File.InputStreamWrapper(), (java.io.InputStream)(_newsocket.getInputStream())),(anywheresoftware.b4a.objects.streams.File.OutputStreamWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.streams.File.OutputStreamWrapper(), (java.io.OutputStream)(_newsocket.getOutputStream())));
 //BA.debugLineNum = 93;BA.debugLine="WifiStatus = \"Connected\"";
_wifistatus = "Connected";
 }else {
 //BA.debugLineNum = 95;BA.debugLine="WifiStatus = \"Error: \" & LastException";
_wifistatus = "Error: "+BA.ObjectToString(anywheresoftware.b4a.keywords.Common.LastException(processBA));
 };
 //BA.debugLineNum = 97;BA.debugLine="UpdateUI";
_updateui();
 //BA.debugLineNum = 98;BA.debugLine="server.Listen";
_server.Listen();
 //BA.debugLineNum = 99;BA.debugLine="End Sub";
return "";
}
public static String  _service_create() throws Exception{
 //BA.debugLineNum = 22;BA.debugLine="Sub Service_Create";
 //BA.debugLineNum = 24;BA.debugLine="server.Initialize(port, \"server\")";
_server.Initialize(processBA,_port,"server");
 //BA.debugLineNum = 25;BA.debugLine="Try";
try { //BA.debugLineNum = 26;BA.debugLine="server.Listen";
_server.Listen();
 } 
       catch (Exception e5) {
			processBA.setLastException(e5); //BA.debugLineNum = 28;BA.debugLine="WifiStatus = \"Error listening: \" & LastException";
_wifistatus = "Error listening: "+BA.ObjectToString(anywheresoftware.b4a.keywords.Common.LastException(processBA));
 //BA.debugLineNum = 29;BA.debugLine="UpdateUI";
_updateui();
 };
 //BA.debugLineNum = 31;BA.debugLine="admin.Initialize(\"admin\")";
_admin.Initialize(processBA,"admin");
 //BA.debugLineNum = 32;BA.debugLine="serial1.Initialize(\"serial1\")";
_serial1.Initialize("serial1");
 //BA.debugLineNum = 33;BA.debugLine="If serial1.IsEnabled Then serial1.Listen2(\"na\", u";
if (_serial1.IsEnabled()) { 
_serial1.Listen2("na",_uuid,processBA);};
 //BA.debugLineNum = 34;BA.debugLine="pe.Initialize(\"pe\")";
_pe.Initialize(processBA,"pe");
 //BA.debugLineNum = 35;BA.debugLine="pe_ConnectivityChanged(\"\", \"\", Null)";
_pe_connectivitychanged("","",(anywheresoftware.b4a.objects.IntentWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.IntentWrapper(), (android.content.Intent)(anywheresoftware.b4a.keywords.Common.Null)));
 //BA.debugLineNum = 36;BA.debugLine="audioStream.Initialize(\"AudioStream\", 22050, True";
_audiostream.Initialize(processBA,"AudioStream",(int) (22050),anywheresoftware.b4a.keywords.Common.True,(int) (16),_audiostream.VOLUME_MUSIC);
 //BA.debugLineNum = 37;BA.debugLine="End Sub";
return "";
}
public static String  _service_destroy() throws Exception{
 //BA.debugLineNum = 164;BA.debugLine="Sub Service_Destroy";
 //BA.debugLineNum = 166;BA.debugLine="End Sub";
return "";
}
public static String  _service_start(anywheresoftware.b4a.objects.IntentWrapper _startingintent) throws Exception{
 //BA.debugLineNum = 48;BA.debugLine="Sub Service_Start (StartingIntent As Intent)";
 //BA.debugLineNum = 50;BA.debugLine="End Sub";
return "";
}
public static String  _socket1_connected(boolean _successful) throws Exception{
 //BA.debugLineNum = 76;BA.debugLine="Private Sub socket1_Connected (Successful As Boole";
 //BA.debugLineNum = 78;BA.debugLine="If Successful Then";
if (_successful) { 
 //BA.debugLineNum = 79;BA.debugLine="WifiConnected = True";
_wificonnected = anywheresoftware.b4a.keywords.Common.True;
 //BA.debugLineNum = 80;BA.debugLine="StartAStream(socket1.InputStream, socket1.Output";
_startastream((anywheresoftware.b4a.objects.streams.File.InputStreamWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.streams.File.InputStreamWrapper(), (java.io.InputStream)(_socket1.getInputStream())),(anywheresoftware.b4a.objects.streams.File.OutputStreamWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.streams.File.OutputStreamWrapper(), (java.io.OutputStream)(_socket1.getOutputStream())));
 //BA.debugLineNum = 81;BA.debugLine="WifiStatus = \"Connected\"";
_wifistatus = "Connected";
 }else {
 //BA.debugLineNum = 83;BA.debugLine="WifiStatus = \"Error: \" & LastException";
_wifistatus = "Error: "+BA.ObjectToString(anywheresoftware.b4a.keywords.Common.LastException(processBA));
 };
 //BA.debugLineNum = 85;BA.debugLine="UpdateUI";
_updateui();
 //BA.debugLineNum = 86;BA.debugLine="End Sub";
return "";
}
public static String  _startastream(anywheresoftware.b4a.objects.streams.File.InputStreamWrapper _in,anywheresoftware.b4a.objects.streams.File.OutputStreamWrapper _out) throws Exception{
 //BA.debugLineNum = 112;BA.debugLine="Private Sub StartAStream (In As InputStream, out A";
 //BA.debugLineNum = 113;BA.debugLine="Log(\"StartAStream\")";
anywheresoftware.b4a.keywords.Common.LogImpl("41900545","StartAStream",0);
 //BA.debugLineNum = 114;BA.debugLine="astream.InitializePrefix(In, True, out, \"astream\"";
_astream.InitializePrefix(processBA,(java.io.InputStream)(_in.getObject()),anywheresoftware.b4a.keywords.Common.True,(java.io.OutputStream)(_out.getObject()),"astream");
 //BA.debugLineNum = 116;BA.debugLine="audioStream.StartPlaying";
_audiostream.StartPlaying();
 //BA.debugLineNum = 117;BA.debugLine="End Sub";
return "";
}
public static String  _stopsendingaudio() throws Exception{
 //BA.debugLineNum = 124;BA.debugLine="Public Sub StopSendingAudio";
 //BA.debugLineNum = 125;BA.debugLine="audioStream.StopRecording";
_audiostream.StopRecording();
 //BA.debugLineNum = 126;BA.debugLine="sendingAudio = False";
_sendingaudio = anywheresoftware.b4a.keywords.Common.False;
 //BA.debugLineNum = 127;BA.debugLine="End Sub";
return "";
}
public static String  _updateui() throws Exception{
 //BA.debugLineNum = 51;BA.debugLine="Private Sub UpdateUI";
 //BA.debugLineNum = 52;BA.debugLine="CallSub(Main, \"UpdateUI\")";
anywheresoftware.b4a.keywords.Common.CallSubNew(processBA,(Object)(mostCurrent._main.getObject()),"UpdateUI");
 //BA.debugLineNum = 53;BA.debugLine="End Sub";
return "";
}
}
