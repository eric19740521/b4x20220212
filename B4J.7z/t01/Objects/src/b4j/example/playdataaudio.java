package b4j.example;

import javax.sound.sampled.*;

import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;

public class playdataaudio extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    public static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new  anywheresoftware.b4j.objects.FxBA("b4j.example", "b4j.example.playdataaudio", this);
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            ba.htSubs = htSubs;
             
        }
        if (BA.isShellModeRuntimeCheck(ba))
                this.getClass().getMethod("_class_globals", b4j.example.playdataaudio.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public anywheresoftware.b4j.object.JavaObject _nativeme = null;
public b4j.example.main _main = null;
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 1;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 2;BA.debugLine="Private nativeMe As JavaObject";
_nativeme = new anywheresoftware.b4j.object.JavaObject();
 //BA.debugLineNum = 4;BA.debugLine="End Sub";
return "";
}
public String  _initialize(anywheresoftware.b4a.BA _ba) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 7;BA.debugLine="Public Sub Initialize";
 //BA.debugLineNum = 9;BA.debugLine="nativeMe = Me";
_nativeme = (anywheresoftware.b4j.object.JavaObject) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.object.JavaObject(), (java.lang.Object)(this));
 //BA.debugLineNum = 10;BA.debugLine="nativeMe.RunMethod( \"initialaudio\", Null)";
_nativeme.RunMethod("initialaudio",(Object[])(__c.Null));
 //BA.debugLineNum = 15;BA.debugLine="End Sub";
return "";
}
public String  _senddataplayer(byte[] _data) throws Exception{
 //BA.debugLineNum = 25;BA.debugLine="Public Sub SendDataPlayer (data() As Byte)";
 //BA.debugLineNum = 26;BA.debugLine="nativeMe.RunMethod( \"playaudio\", Array(data,data.";
_nativeme.RunMethod("playaudio",new Object[]{(Object)(_data),(Object)(_data.length)});
 //BA.debugLineNum = 27;BA.debugLine="End Sub";
return "";
}
public String  _startaudioplayer() throws Exception{
 //BA.debugLineNum = 17;BA.debugLine="Public Sub StartAudioPlayer";
 //BA.debugLineNum = 18;BA.debugLine="nativeMe.RunMethod( \"startaudio\", Null)";
_nativeme.RunMethod("startaudio",(Object[])(__c.Null));
 //BA.debugLineNum = 19;BA.debugLine="End Sub";
return "";
}
public String  _stopaudioplayer() throws Exception{
 //BA.debugLineNum = 21;BA.debugLine="Public Sub StopAudioPlayer";
 //BA.debugLineNum = 22;BA.debugLine="nativeMe.RunMethod( \"stopaudio\", Null)";
_nativeme.RunMethod("stopaudio",(Object[])(__c.Null));
 //BA.debugLineNum = 23;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}

	SourceDataLine _speaker;

    public void initialaudio() throws LineUnavailableException{
        //  specifying the audio format
        AudioFormat _format = new AudioFormat(22050.F,// Sample Rate
                16,     // Size of SampleBits
                1,      // Number of Channels
                true,   // Is Signed?
                false   // Is Big Endian?
        );

        //  creating the DataLine Info For the speaker format
        DataLine.Info speakerInfo = new DataLine.Info(SourceDataLine.class, _format);

        //  getting the mixer For the speaker
        _speaker = (SourceDataLine) AudioSystem.getLine(speakerInfo);
        _speaker.open(_format);
    }

    public void startaudio() {
        try {
            _speaker.start();
        } catch (Exception e) {
            e.printStackTrace();
        }
		
    }		
    public void playaudio(byte[] data, int readCount) {
        try {
			if(readCount > 0){
                    _speaker.write(data, 0, readCount);
             }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
		
	public void stopaudio() {
        try {
            _speaker.drain();
            _speaker.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


}
