package b4j.example;


import anywheresoftware.b4a.BA;

public class main extends javafx.application.Application{
public static main mostCurrent = new main();

public static BA ba;
static {
		ba = new  anywheresoftware.b4j.objects.FxBA("b4j.example", "b4j.example.main", null);
		ba.loadHtSubs(main.class);
        if (ba.getClass().getName().endsWith("ShellBA")) {
			
			ba.raiseEvent2(null, true, "SHELL", false);
			ba.raiseEvent2(null, true, "CREATE", true, "b4j.example.main", ba);
		}
	}
    public static Class<?> getObject() {
		return main.class;
	}

 
    public static void main(String[] args) {
    	launch(args);
    }
    public void start (javafx.stage.Stage stage) {
        try {
            if (!false)
                System.setProperty("prism.lcdtext", "false");
            anywheresoftware.b4j.objects.FxBA.application = this;
		    anywheresoftware.b4a.keywords.Common.setDensity(javafx.stage.Screen.getPrimary().getDpi());
            anywheresoftware.b4a.keywords.Common.LogDebug("Program started.");
            initializeProcessGlobals();
            anywheresoftware.b4j.objects.Form frm = new anywheresoftware.b4j.objects.Form();
            frm.initWithStage(ba, stage, 600, 600);
            ba.raiseEvent(null, "appstart", frm, (String[])getParameters().getRaw().toArray(new String[0]));
        } catch (Throwable t) {
            BA.printException(t, true);
            System.exit(1);
        }
    }
public static anywheresoftware.b4a.keywords.Common __c = null;
public static anywheresoftware.b4j.objects.JFX _fx = null;
public static anywheresoftware.b4j.objects.Form _mainform = null;
public static anywheresoftware.b4a.objects.B4XViewWrapper.XUI _xui = null;
public static anywheresoftware.b4a.objects.B4XViewWrapper _button1 = null;
public static boolean _wificonnected = false;
public static boolean _btconnected = false;
public static boolean _activelisten = false;
public static anywheresoftware.b4a.objects.SocketWrapper _socket1 = null;
public static anywheresoftware.b4a.objects.SocketWrapper.ServerSocketWrapper _server = null;
public static anywheresoftware.b4a.randomaccessfile.AsyncStreams _astream = null;
public static int _port = 0;
public static int _buffersize = 0;
public static String _address = "";
public static com.stevel05.JAudioRecord _audiostream = null;
public static b4j.example.playdataaudio _audio = null;
public static anywheresoftware.b4j.objects.LabelWrapper _lblip = null;
public static anywheresoftware.b4j.objects.LabelWrapper _lblwifistatus = null;
public static anywheresoftware.b4j.objects.ButtonWrapper _btnconnectwifi = null;
public static anywheresoftware.b4j.objects.TextInputControlWrapper.TextFieldWrapper _edtip = null;
public static anywheresoftware.b4j.objects.ButtonWrapper _button2 = null;
public static String  _appstart(anywheresoftware.b4j.objects.Form _form1,String[] _args) throws Exception{
 //BA.debugLineNum = 31;BA.debugLine="Sub AppStart (Form1 As Form, Args() As String)";
 //BA.debugLineNum = 32;BA.debugLine="MainForm = Form1";
_mainform = _form1;
 //BA.debugLineNum = 33;BA.debugLine="MainForm.RootPane.LoadLayout(\"Layout1\")";
_mainform.getRootPane().LoadLayout(ba,"Layout1");
 //BA.debugLineNum = 34;BA.debugLine="MainForm.Show";
_mainform.Show();
 //BA.debugLineNum = 37;BA.debugLine="audio.Initialize";
_audio._initialize /*String*/ (ba);
 //BA.debugLineNum = 38;BA.debugLine="audio.StartAudioPlayer";
_audio._startaudioplayer /*String*/ ();
 //BA.debugLineNum = 41;BA.debugLine="audioStream.Initialize(22050, 16,audioStream.CH_C";
_audiostream.Initialize(ba,(float) (22050),(int) (16),_audiostream.CH_CONF_MONO);
 //BA.debugLineNum = 43;BA.debugLine="server.Initialize(port, \"server\")";
_server.Initialize(ba,_port,"server");
 //BA.debugLineNum = 45;BA.debugLine="lblIP.Text = server.GetMyIP";
_lblip.setText(_server.GetMyIP());
 //BA.debugLineNum = 46;BA.debugLine="lblWifiStatus.Text = \"斷開\"";
_lblwifistatus.setText("斷開");
 //BA.debugLineNum = 47;BA.debugLine="Try";
try { //BA.debugLineNum = 48;BA.debugLine="server.Listen";
_server.Listen();
 } 
       catch (Exception e13) {
			ba.setLastException(e13); };
 //BA.debugLineNum = 56;BA.debugLine="End Sub";
return "";
}
public static String  _astream_error() throws Exception{
 //BA.debugLineNum = 107;BA.debugLine="Sub Astream_Error";
 //BA.debugLineNum = 108;BA.debugLine="Log(\"Error: \" & LastException)";
anywheresoftware.b4a.keywords.Common.LogImpl("7458753","Error: "+BA.ObjectToString(anywheresoftware.b4a.keywords.Common.LastException(ba)),0);
 //BA.debugLineNum = 109;BA.debugLine="astream.Close";
_astream.Close();
 //BA.debugLineNum = 110;BA.debugLine="AStream_Terminated 'manually call this method as";
_astream_terminated();
 //BA.debugLineNum = 112;BA.debugLine="End Sub";
return "";
}
public static String  _astream_newdata(byte[] _buffer) throws Exception{
 //BA.debugLineNum = 91;BA.debugLine="Sub astream_NewData (Buffer() As Byte)";
 //BA.debugLineNum = 93;BA.debugLine="Log(\"astream_NewData==>\")";
anywheresoftware.b4a.keywords.Common.LogImpl("7393218","astream_NewData==>",0);
 //BA.debugLineNum = 95;BA.debugLine="Log($\"Riceve: ${Buffer.Length}\"$)";
anywheresoftware.b4a.keywords.Common.LogImpl("7393220",("Riceve: "+anywheresoftware.b4a.keywords.Common.SmartStringFormatter("",(Object)(_buffer.length))+""),0);
 //BA.debugLineNum = 97;BA.debugLine="audio.SendDataPlayer(Buffer)";
_audio._senddataplayer /*String*/ (_buffer);
 //BA.debugLineNum = 103;BA.debugLine="Log(\"audio end\")";
anywheresoftware.b4a.keywords.Common.LogImpl("7393228","audio end",0);
 //BA.debugLineNum = 104;BA.debugLine="End Sub";
return "";
}
public static String  _astream_terminated() throws Exception{
 //BA.debugLineNum = 114;BA.debugLine="Sub AStream_Terminated";
 //BA.debugLineNum = 115;BA.debugLine="Log(\"AStream_Terminated==>\")";
anywheresoftware.b4a.keywords.Common.LogImpl("7524289","AStream_Terminated==>",0);
 //BA.debugLineNum = 117;BA.debugLine="WifiConnected = False";
_wificonnected = anywheresoftware.b4a.keywords.Common.False;
 //BA.debugLineNum = 119;BA.debugLine="UpdateUI";
_updateui();
 //BA.debugLineNum = 120;BA.debugLine="End Sub";
return "";
}
public static String  _btnconnectwifi_click() throws Exception{
 //BA.debugLineNum = 157;BA.debugLine="Private Sub btnConnectWifi_Click";
 //BA.debugLineNum = 158;BA.debugLine="Log(\"Trying to connect...\")";
anywheresoftware.b4a.keywords.Common.LogImpl("7720897","Trying to connect...",0);
 //BA.debugLineNum = 160;BA.debugLine="socket1.Initialize(\"socket1\")";
_socket1.Initialize("socket1");
 //BA.debugLineNum = 161;BA.debugLine="socket1.Connect(edtIP.Text, port, 30000)";
_socket1.Connect(ba,_edtip.getText(),_port,(int) (30000));
 //BA.debugLineNum = 163;BA.debugLine="UpdateUI";
_updateui();
 //BA.debugLineNum = 164;BA.debugLine="End Sub";
return "";
}
public static String  _button1_click() throws Exception{
 //BA.debugLineNum = 66;BA.debugLine="Sub Button1_Click";
 //BA.debugLineNum = 67;BA.debugLine="xui.MsgboxAsync(\"Hello World!\", \"B4X\")";
_xui.MsgboxAsync(ba,"Hello World!","B4X");
 //BA.debugLineNum = 68;BA.debugLine="End Sub";
return "";
}
public static String  _button2_click() throws Exception{
 //BA.debugLineNum = 202;BA.debugLine="Private Sub Button2_Click";
 //BA.debugLineNum = 203;BA.debugLine="Log(\"Button2_Click==>\")";
anywheresoftware.b4a.keywords.Common.LogImpl("7917505","Button2_Click==>",0);
 //BA.debugLineNum = 205;BA.debugLine="If ActiveListen=False Then";
if (_activelisten==anywheresoftware.b4a.keywords.Common.False) { 
 //BA.debugLineNum = 206;BA.debugLine="ActiveListen=True";
_activelisten = anywheresoftware.b4a.keywords.Common.True;
 }else {
 //BA.debugLineNum = 210;BA.debugLine="ActiveListen=False";
_activelisten = anywheresoftware.b4a.keywords.Common.False;
 };
 //BA.debugLineNum = 213;BA.debugLine="OpenTrasmits";
_opentrasmits();
 //BA.debugLineNum = 215;BA.debugLine="Button2.Text = ActiveListen";
_button2.setText(BA.ObjectToString(_activelisten));
 //BA.debugLineNum = 217;BA.debugLine="End Sub";
return "";
}
public static String  _closetrasmits() throws Exception{
 //BA.debugLineNum = 243;BA.debugLine="Public Sub CloseTrasmits";
 //BA.debugLineNum = 244;BA.debugLine="audioStream.Stop";
_audiostream.Stop();
 //BA.debugLineNum = 245;BA.debugLine="ActiveListen=False";
_activelisten = anywheresoftware.b4a.keywords.Common.False;
 //BA.debugLineNum = 246;BA.debugLine="End Sub";
return "";
}
public static String  _closewavefile(String _dir,String _filename) throws Exception{
anywheresoftware.b4a.randomaccessfile.RandomAccessFile _raf = null;
 //BA.debugLineNum = 192;BA.debugLine="Sub CloseWaveFile(Dir As String, FileName As Strin";
 //BA.debugLineNum = 193;BA.debugLine="Dim raf As RandomAccessFile";
_raf = new anywheresoftware.b4a.randomaccessfile.RandomAccessFile();
 //BA.debugLineNum = 194;BA.debugLine="raf.Initialize2(Dir, FileName, False, True)";
_raf.Initialize2(_dir,_filename,anywheresoftware.b4a.keywords.Common.False,anywheresoftware.b4a.keywords.Common.True);
 //BA.debugLineNum = 195;BA.debugLine="raf.WriteInt(raf.Size - 8, 4)";
_raf.WriteInt((int) (_raf.getSize()-8),(long) (4));
 //BA.debugLineNum = 196;BA.debugLine="raf.WriteInt(raf.Size - 44, 40)";
_raf.WriteInt((int) (_raf.getSize()-44),(long) (40));
 //BA.debugLineNum = 197;BA.debugLine="raf.Close";
_raf.Close();
 //BA.debugLineNum = 198;BA.debugLine="End Sub";
return "";
}
public static String  _mainform_closerequest(anywheresoftware.b4j.objects.NodeWrapper.ConcreteEventWrapper _eventdata) throws Exception{
 //BA.debugLineNum = 61;BA.debugLine="Sub MainForm_CloseRequest (EventData As Event)";
 //BA.debugLineNum = 64;BA.debugLine="End Sub";
return "";
}
public static String  _mainform_resize(double _width,double _height) throws Exception{
 //BA.debugLineNum = 57;BA.debugLine="Sub MainForm_Resize (Width As Double, Height As Do";
 //BA.debugLineNum = 59;BA.debugLine="End Sub";
return "";
}
public static void  _opentrasmits() throws Exception{
ResumableSub_OpenTrasmits rsub = new ResumableSub_OpenTrasmits(null);
rsub.resume(ba, null);
}
public static class ResumableSub_OpenTrasmits extends BA.ResumableSub {
public ResumableSub_OpenTrasmits(b4j.example.main parent) {
this.parent = parent;
}
b4j.example.main parent;
int _bytesread = 0;
int _recdatasize = 0;
byte[] _recdata = null;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 222;BA.debugLine="Dim BytesRead As Int = 0";
_bytesread = (int) (0);
 //BA.debugLineNum = 223;BA.debugLine="Dim RecDataSize As Int = BufferSize";
_recdatasize = parent._buffersize;
 //BA.debugLineNum = 225;BA.debugLine="audioStream.Start";
parent._audiostream.Start();
 //BA.debugLineNum = 227;BA.debugLine="Do While ActiveListen";
if (true) break;

case 1:
//do while
this.state = 4;
while (parent._activelisten) {
this.state = 3;
if (true) break;
}
if (true) break;

case 3:
//C
this.state = 1;
 //BA.debugLineNum = 229;BA.debugLine="Dim RecData(RecDataSize) As Byte";
_recdata = new byte[_recdatasize];
;
 //BA.debugLineNum = 230;BA.debugLine="BytesRead = audioStream.Read(RecData,0,RecData.L";
_bytesread = parent._audiostream.Read(_recdata,(int) (0),_recdata.length);
 //BA.debugLineNum = 233;BA.debugLine="Log($\"Send( ): ${BytesRead}\"$)";
anywheresoftware.b4a.keywords.Common.LogImpl("7983052",("Send( ): "+anywheresoftware.b4a.keywords.Common.SmartStringFormatter("",(Object)(_bytesread))+""),0);
 //BA.debugLineNum = 237;BA.debugLine="astream.Write(RecData)";
parent._astream.Write(_recdata);
 //BA.debugLineNum = 239;BA.debugLine="Sleep(0)";
anywheresoftware.b4a.keywords.Common.Sleep(ba,this,(int) (0));
this.state = 5;
return;
case 5:
//C
this.state = 1;
;
 if (true) break;

case 4:
//C
this.state = -1;
;
 //BA.debugLineNum = 241;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}

private static boolean processGlobalsRun;
public static void initializeProcessGlobals() {
    
    if (main.processGlobalsRun == false) {
	    main.processGlobalsRun = true;
		try {
		        main._process_globals();
		
        } catch (Exception e) {
			throw new RuntimeException(e);
		}
    }
}public static String  _process_globals() throws Exception{
 //BA.debugLineNum = 6;BA.debugLine="Sub Process_Globals";
 //BA.debugLineNum = 7;BA.debugLine="Private fx As JFX";
_fx = new anywheresoftware.b4j.objects.JFX();
 //BA.debugLineNum = 8;BA.debugLine="Private MainForm As Form";
_mainform = new anywheresoftware.b4j.objects.Form();
 //BA.debugLineNum = 9;BA.debugLine="Private xui As XUI";
_xui = new anywheresoftware.b4a.objects.B4XViewWrapper.XUI();
 //BA.debugLineNum = 10;BA.debugLine="Private Button1 As B4XView";
_button1 = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 11;BA.debugLine="Private xui As XUI";
_xui = new anywheresoftware.b4a.objects.B4XViewWrapper.XUI();
 //BA.debugLineNum = 13;BA.debugLine="Public WifiConnected, BTConnected,ActiveListen As";
_wificonnected = false;
_btconnected = false;
_activelisten = false;
 //BA.debugLineNum = 14;BA.debugLine="Private socket1 As Socket";
_socket1 = new anywheresoftware.b4a.objects.SocketWrapper();
 //BA.debugLineNum = 15;BA.debugLine="Private server As ServerSocket";
_server = new anywheresoftware.b4a.objects.SocketWrapper.ServerSocketWrapper();
 //BA.debugLineNum = 16;BA.debugLine="Private astream As AsyncStreams";
_astream = new anywheresoftware.b4a.randomaccessfile.AsyncStreams();
 //BA.debugLineNum = 17;BA.debugLine="Private port As Int = 21341";
_port = (int) (21341);
 //BA.debugLineNum = 18;BA.debugLine="Private BufferSize As Int = 8192";
_buffersize = (int) (8192);
 //BA.debugLineNum = 19;BA.debugLine="Public address As String = \"192.168.1.147\"";
_address = "192.168.1.147";
 //BA.debugLineNum = 21;BA.debugLine="Private audioStream As AudioRecord";
_audiostream = new com.stevel05.JAudioRecord();
 //BA.debugLineNum = 22;BA.debugLine="Private audio As PlayDataAudio";
_audio = new b4j.example.playdataaudio();
 //BA.debugLineNum = 23;BA.debugLine="Private lblIP As Label";
_lblip = new anywheresoftware.b4j.objects.LabelWrapper();
 //BA.debugLineNum = 24;BA.debugLine="Private lblWifiStatus As Label";
_lblwifistatus = new anywheresoftware.b4j.objects.LabelWrapper();
 //BA.debugLineNum = 26;BA.debugLine="Private btnConnectWifi As Button";
_btnconnectwifi = new anywheresoftware.b4j.objects.ButtonWrapper();
 //BA.debugLineNum = 27;BA.debugLine="Private edtIP As TextField";
_edtip = new anywheresoftware.b4j.objects.TextInputControlWrapper.TextFieldWrapper();
 //BA.debugLineNum = 28;BA.debugLine="Private Button2 As Button";
_button2 = new anywheresoftware.b4j.objects.ButtonWrapper();
 //BA.debugLineNum = 29;BA.debugLine="End Sub";
return "";
}
public static String  _server_newconnection(boolean _successful,anywheresoftware.b4a.objects.SocketWrapper _newsocket) throws Exception{
 //BA.debugLineNum = 72;BA.debugLine="Private Sub server_NewConnection (Successful As Bo";
 //BA.debugLineNum = 74;BA.debugLine="If Successful Then";
if (_successful) { 
 //BA.debugLineNum = 76;BA.debugLine="WifiConnected = True";
_wificonnected = anywheresoftware.b4a.keywords.Common.True;
 //BA.debugLineNum = 77;BA.debugLine="astream.InitializePrefix(NewSocket.InputStream,";
_astream.InitializePrefix(ba,_newsocket.getInputStream(),anywheresoftware.b4a.keywords.Common.True,_newsocket.getOutputStream(),"astream");
 }else {
 //BA.debugLineNum = 81;BA.debugLine="WifiConnected = False";
_wificonnected = anywheresoftware.b4a.keywords.Common.False;
 };
 //BA.debugLineNum = 84;BA.debugLine="UpdateUI";
_updateui();
 //BA.debugLineNum = 87;BA.debugLine="server.Listen";
_server.Listen();
 //BA.debugLineNum = 88;BA.debugLine="End Sub";
return "";
}
public static String  _socket1_connected(boolean _successful) throws Exception{
 //BA.debugLineNum = 123;BA.debugLine="Private Sub socket1_Connected (Successful As Boole";
 //BA.debugLineNum = 125;BA.debugLine="If Successful Then";
if (_successful) { 
 //BA.debugLineNum = 127;BA.debugLine="WifiConnected = True";
_wificonnected = anywheresoftware.b4a.keywords.Common.True;
 //BA.debugLineNum = 129;BA.debugLine="astream.InitializePrefix(socket1.InputStream, Tr";
_astream.InitializePrefix(ba,_socket1.getInputStream(),anywheresoftware.b4a.keywords.Common.True,_socket1.getOutputStream(),"astream");
 }else {
 //BA.debugLineNum = 132;BA.debugLine="WifiConnected = False";
_wificonnected = anywheresoftware.b4a.keywords.Common.False;
 };
 //BA.debugLineNum = 134;BA.debugLine="UpdateUI";
_updateui();
 //BA.debugLineNum = 136;BA.debugLine="End Sub";
return "";
}
public static anywheresoftware.b4a.objects.streams.File.OutputStreamWrapper  _startwavefile(String _dir,String _filename,int _samplerate,boolean _mono,int _bitspersample) throws Exception{
anywheresoftware.b4a.randomaccessfile.RandomAccessFile _raf = null;
int _numberofchannels = 0;
 //BA.debugLineNum = 168;BA.debugLine="Sub StartWaveFile(Dir As String, FileName As Strin";
 //BA.debugLineNum = 170;BA.debugLine="File.Delete(Dir, FileName)";
anywheresoftware.b4a.keywords.Common.File.Delete(_dir,_filename);
 //BA.debugLineNum = 171;BA.debugLine="Dim raf As RandomAccessFile";
_raf = new anywheresoftware.b4a.randomaccessfile.RandomAccessFile();
 //BA.debugLineNum = 172;BA.debugLine="raf.Initialize2(Dir, FileName, False, True)";
_raf.Initialize2(_dir,_filename,anywheresoftware.b4a.keywords.Common.False,anywheresoftware.b4a.keywords.Common.True);
 //BA.debugLineNum = 173;BA.debugLine="raf.WriteBytes(\"RIFF\".GetBytes(\"ASCII\"), 0, 4, ra";
_raf.WriteBytes("RIFF".getBytes("ASCII"),(int) (0),(int) (4),_raf.CurrentPosition);
 //BA.debugLineNum = 174;BA.debugLine="raf.CurrentPosition = 8 'skip 4 bytes for the siz";
_raf.CurrentPosition = (long) (8);
 //BA.debugLineNum = 175;BA.debugLine="raf.WriteBytes(\"WAVE\".GetBytes(\"ASCII\"),0, 4, raf";
_raf.WriteBytes("WAVE".getBytes("ASCII"),(int) (0),(int) (4),_raf.CurrentPosition);
 //BA.debugLineNum = 176;BA.debugLine="raf.WriteBytes(\"fmt \".GetBytes(\"ASCII\"),0, 4, raf";
_raf.WriteBytes("fmt ".getBytes("ASCII"),(int) (0),(int) (4),_raf.CurrentPosition);
 //BA.debugLineNum = 177;BA.debugLine="raf.WriteInt(16, raf.CurrentPosition)";
_raf.WriteInt((int) (16),_raf.CurrentPosition);
 //BA.debugLineNum = 178;BA.debugLine="raf.WriteShort(1, raf.CurrentPosition)";
_raf.WriteShort((short) (1),_raf.CurrentPosition);
 //BA.debugLineNum = 179;BA.debugLine="Dim numberOfChannels As Int";
_numberofchannels = 0;
 //BA.debugLineNum = 180;BA.debugLine="If Mono Then numberOfChannels = 1 Else numberOfCh";
if (_mono) { 
_numberofchannels = (int) (1);}
else {
_numberofchannels = (int) (2);};
 //BA.debugLineNum = 181;BA.debugLine="raf.WriteShort(numberOfChannels, raf.CurrentPosit";
_raf.WriteShort((short) (_numberofchannels),_raf.CurrentPosition);
 //BA.debugLineNum = 182;BA.debugLine="raf.WriteInt(SampleRate, raf.CurrentPosition)";
_raf.WriteInt(_samplerate,_raf.CurrentPosition);
 //BA.debugLineNum = 183;BA.debugLine="raf.WriteInt(SampleRate * numberOfChannels * Bits";
_raf.WriteInt((int) (_samplerate*_numberofchannels*_bitspersample/(double)8),_raf.CurrentPosition);
 //BA.debugLineNum = 184;BA.debugLine="raf.WriteShort(numberOfChannels * BitsPerSample /";
_raf.WriteShort((short) (_numberofchannels*_bitspersample/(double)8),_raf.CurrentPosition);
 //BA.debugLineNum = 185;BA.debugLine="raf.WriteShort(BitsPerSample, raf.CurrentPosition";
_raf.WriteShort((short) (_bitspersample),_raf.CurrentPosition);
 //BA.debugLineNum = 186;BA.debugLine="raf.WriteBytes(\"data\".GetBytes(\"ASCII\"),0, 4, raf";
_raf.WriteBytes("data".getBytes("ASCII"),(int) (0),(int) (4),_raf.CurrentPosition);
 //BA.debugLineNum = 187;BA.debugLine="raf.WriteInt(0, raf.CurrentPosition)";
_raf.WriteInt((int) (0),_raf.CurrentPosition);
 //BA.debugLineNum = 188;BA.debugLine="raf.Close";
_raf.Close();
 //BA.debugLineNum = 189;BA.debugLine="Return File.OpenOutput(Dir, FileName, True)";
if (true) return anywheresoftware.b4a.keywords.Common.File.OpenOutput(_dir,_filename,anywheresoftware.b4a.keywords.Common.True);
 //BA.debugLineNum = 190;BA.debugLine="End Sub";
return null;
}
public static String  _updateui() throws Exception{
 //BA.debugLineNum = 138;BA.debugLine="Public Sub UpdateUI";
 //BA.debugLineNum = 141;BA.debugLine="lblIP.Text = server.GetMyIP";
_lblip.setText(_server.GetMyIP());
 //BA.debugLineNum = 142;BA.debugLine="If WifiConnected Then";
if (_wificonnected) { 
 //BA.debugLineNum = 143;BA.debugLine="lblWifiStatus.Text = \"連上\"";
_lblwifistatus.setText("連上");
 //BA.debugLineNum = 144;BA.debugLine="btnConnectWifi.Enabled =False";
_btnconnectwifi.setEnabled(anywheresoftware.b4a.keywords.Common.False);
 }else {
 //BA.debugLineNum = 148;BA.debugLine="btnConnectWifi.Enabled =True";
_btnconnectwifi.setEnabled(anywheresoftware.b4a.keywords.Common.True);
 //BA.debugLineNum = 149;BA.debugLine="lblWifiStatus.Text = \"斷開\"";
_lblwifistatus.setText("斷開");
 };
 //BA.debugLineNum = 154;BA.debugLine="End Sub";
return "";
}
}
